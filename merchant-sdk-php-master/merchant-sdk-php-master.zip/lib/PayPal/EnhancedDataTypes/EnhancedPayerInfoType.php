<?php
namespace PayPal\EnhancedDataTypes;

use PayPal\Core\PPXmlMessage;

/**
 *
 */
class EnhancedPayerInfoType
  extends PPXmlMessage
{

}
