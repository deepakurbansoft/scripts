<?php
namespace PayPal\PayPalAPI;

use PayPal\EBLBaseComponents\AbstractResponseType;

/**
 *
 */
class DoNonReferencedCreditResponseType
  extends AbstractResponseType
{

    /**
     *
     * @access    public
     * @namespace ebl
     * @var \PayPal\EBLBaseComponents\DoNonReferencedCreditResponseDetailsType
     */
    public $DoNonReferencedCreditResponseDetails;

}
