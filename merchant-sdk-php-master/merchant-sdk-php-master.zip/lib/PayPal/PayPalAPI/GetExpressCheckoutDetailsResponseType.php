<?php
namespace PayPal\PayPalAPI;

use PayPal\EBLBaseComponents\AbstractResponseType;

/**
 *
 */
class GetExpressCheckoutDetailsResponseType
  extends AbstractResponseType
{

    /**
     *
     * @access    public
     * @namespace ebl
     * @var \PayPal\EBLBaseComponents\GetExpressCheckoutDetailsResponseDetailsType
     */
    public $GetExpressCheckoutDetailsResponseDetails;

}
