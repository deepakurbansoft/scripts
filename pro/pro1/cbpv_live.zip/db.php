<?php

if($_SERVER['SERVER_NAME'] == 'localhost')
{
    mysql_connect('localhost','root','');
    mysql_select_db('cbpc');
    mysql_query('set names utf8');
    define("site_url", "http://localhost/cashbookpickandclick.com");

}
else
{
    mysql_connect('localhost','urbancc_urban','Urb@ns0ft@123.');
    mysql_select_db('cbpc');
    mysql_query('set names utf8');
    define("site_url", "http://cbpc.urbansoft.cc");
}



error_reporting(0);
//$conn = mysql_connect("localhost","jaikris2_urban","taurbansoft");
//$db = mysql_select_db('jaikris2_demoalmanara');
session_start();

function get_cell($table_name,$id,$cellname)
{
    $cell_array=mysql_fetch_assoc(mysql_query("select `$cellname` from `$table_name` where `id` = '$id'"));

//    echo "select `$cellname` from `$table_name` where `id` = '$id'";
    return $cell_array[$cellname];
}

function get_cell_value($table_name,$condition,$value,$cellname)
{
    $cell_array=mysql_fetch_assoc(mysql_query("select `$cellname` from `$table_name` where `$condition` = '$value'"));

//    echo "select `$cellname` from `$table_name` where `$condition` = '$value'";

    return $cell_array[$cellname];
}
?>