
<form action="insertcoupon.php" method="POST" enctype="multipart/form-data">
  <input type="file" name="imageUpload" id="imageUpload">
    <input type="submit" name="submit"/>
</form>

