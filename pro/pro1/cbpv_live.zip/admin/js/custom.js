$(document).ready(function()
{
    $('input[type="checkbox"]').change(function(event) {

        window.id=$(this).val();
        $('.loading_label'+id).html('<i class="fa fa-circle-o-notch fa-spin fa-2x fa-fw custom_spin"></i>');


        if (this.checked) {

            ajax_process(1);

        }
        else {

            ajax_process(0);

        }
    });

});


function ajax_process(status){

    $.ajax({ //Process the form using $.ajax()
        type      : 'POST', //Method type
        url       : 'process_featuredhome.php', //Your form processing file URL
        data: {id:id,status:status},
        dataType  : 'json',
        success   : function(data) {

            if (data.success) { //If fails

                location.reload();

            }
            else {

                alert('Something Went Wrong. Contact Admin.  ');
            }
        }
    });
}