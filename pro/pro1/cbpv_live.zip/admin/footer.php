<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; 2014-2015 <a href="http://urbansoft.co" target="_blank">Urbansoft</a>.</strong> All rights reserved.
</footer>