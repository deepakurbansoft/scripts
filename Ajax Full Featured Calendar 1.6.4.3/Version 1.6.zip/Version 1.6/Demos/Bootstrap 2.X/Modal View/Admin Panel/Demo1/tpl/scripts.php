<!-- javascript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="js/jquery.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/fullcalendar.js"></script>
<script src="js/gcal.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/jquery.calendar.js"></script>
<script src="lib/colorpicker/bootstrap-colorpicker.js"></script>
<script src="lib/timepicker/bootstrap-timepicker.js"></script>
<script src="lib/validation/jquery.validationEngine.js"></script>
<script src="lib/validation/jquery.validationEngine-en.js"></script>
<script src="js/custom.js"></script>