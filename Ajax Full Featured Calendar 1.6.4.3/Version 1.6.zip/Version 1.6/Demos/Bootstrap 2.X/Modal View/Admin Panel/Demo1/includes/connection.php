<?php
	
	// DB Connection Configuration
	define('DB_HOST', 'localhost'); 
	define('DB_USERNAME', 'test'); 
	define('DB_PASSWORD', '12345'); 
	define('DATABASE', 'calendar'); 
	define('TABLE', 'calendar');
	define('USERS_TABLE', 'users');
	
	// Default Categories
	$categories = array("General","Party","Work");
	
?>