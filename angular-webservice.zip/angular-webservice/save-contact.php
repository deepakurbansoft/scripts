<?php

$data = file_get_contents("php://input");
$objData = json_decode($data);

echo $name = $objData -> name;
echo $email = $objData -> email; //etc


?>


